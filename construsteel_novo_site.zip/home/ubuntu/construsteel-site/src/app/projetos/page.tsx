import Link from "next/link";
import Image from "next/image";
import { ChevronRight } from "lucide-react"; // Removidos: Home, Briefcase, Tractor, Search, Calendar, MapPin, Award

// Mock data para projetos - idealmente viria de um CMS ou API
const mockProjetos = [
  {
    id: "residencial-moderna-01",
    titulo: "Casa Moderna Alphaville",
    nicho: "Residencial",
    tipoProjeto: "Casa de Alto Padrão",
    anoConclusao: 2023,
    localizacao: "Alphaville, SP",
    imagemPrincipal: "/placeholder-projeto-res1.jpg",
    descricaoBreve: "Solução residencial rápida e previsível, eliminando transtornos da construção convencional e entregando um lar com alto padrão de acabamento.",
    desafio: "Cliente buscava uma construção de alto padrão com prazo de entrega reduzido e custos controlados, evitando os imprevistos comuns em obras tradicionais.",
    solucaoConstrusteel: "O ecossistema Construsteel, com perfis de aço e painéis LightWall, permitiu uma montagem precisa e ágil. O planejamento detalhado e a fabricação industrializada garantiram o cumprimento do cronograma e do orçamento, com mínimo desperdício e alta qualidade final.",
    resultadosBeneficios: "Entrega realizada 30% mais rápido que o método convencional, com total satisfação do cliente quanto à qualidade, conforto termoacústico e previsibilidade do investimento.",
    tecnologiaAplicada: "Perfis de aço galvanizado para estrutura e painéis LightWall para fechamentos externos e internos, garantindo isolamento e rapidez.",
    areaConstruida: "350m²",
    imagensGaleria: ["/placeholder-projeto-res1-gal1.jpg", "/placeholder-projeto-res1-gal2.jpg", "/placeholder-projeto-res1-gal3.jpg"],
  },
  {
    id: "corporativo-inovador-01",
    titulo: "Edifício Comercial InovaTech",
    nicho: "Corporativo/Comercial",
    tipoProjeto: "Edifício de Escritórios",
    anoConclusao: 2024,
    localizacao: "São Paulo, SP",
    imagemPrincipal: "/placeholder-projeto-corp1.jpg",
    descricaoBreve: "Expansão de operações comerciais sem paralisação do faturamento, com entrega ágil e flexibilidade para futuras adaptações.",
    desafio: "Empresa em crescimento necessitava de um novo espaço comercial rapidamente para não perder oportunidades de mercado, com um design moderno e adaptável.",
    solucaoConstrusteel: "A Construsteel aplicou seu ecossistema industrializado para construir o Edifício InovaTech em tempo recorde. A tecnologia de perfis de aço e LightWall proporcionou leveza estrutural, permitindo fundações mais simples, e agilidade na montagem das fachadas e divisórias internas.",
    resultadosBeneficios: "Obra concluída 2 meses antes do previsto, permitindo à InovaTech iniciar suas operações mais cedo. O design flexível já permitiu uma reconfiguração interna sem grandes obras.",
    tecnologiaAplicada: "Sistema construtivo misto com perfis de aço e painéis LightWall, fachada ventilada e soluções de automação predial.",
    areaConstruida: "1200m²",
    imagensGaleria: ["/placeholder-projeto-corp1-gal1.jpg", "/placeholder-projeto-corp1-gal2.jpg"],
  },
  {
    id: "agro-eficiente-01",
    titulo: "Armazém Graneleiro AgroFuturo",
    nicho: "Agronegócio",
    tipoProjeto: "Armazém de Grãos",
    anoConclusao: 2023,
    localizacao: "Mato Grosso, MT",
    imagemPrincipal: "/placeholder-projeto-agro1.jpg",
    descricaoBreve: "Instalações duráveis e eficientes em área remota do agronegócio, superando desafios de logística e mão de obra.",
    desafio: "Produtor necessitava de um armazém graneleiro de grande porte em uma fazenda de difícil acesso, com urgência para a próxima safra e dificuldade de encontrar mão de obra especializada localmente.",
    solucaoConstrusteel: "O ecossistema Construsteel foi mobilizado para o local, com componentes fabricados industrialmente e transportados de forma otimizada. A montagem rápida dos perfis de aço e painéis LightWall minimizou a necessidade de equipe no local e garantiu a estanqueidade e durabilidade necessárias para o armazenamento de grãos.",
    resultadosBeneficios: "Armazém entregue a tempo para a colheita, evitando perdas. Estrutura robusta e com baixo custo de manutenção, ideal para as condições do campo.",
    tecnologiaAplicada: "Estrutura em perfis de aço de alta resistência, fechamentos com painéis LightWall com tratamento especial para umidade e vedações reforçadas.",
    areaConstruida: "2500m²",
    imagensGaleria: ["/placeholder-projeto-agro1-gal1.jpg"],
  }
];

export default function ProjetosPage() {
  const projetosFiltrados = mockProjetos;

  return (
    <>
      <section className="bg-gray-700 py-20 text-white text-center" style={{ backgroundImage: "url(\"/projetos-banner.jpg\")", backgroundSize: "cover", backgroundPosition: "center" }}>
        <div className="container mx-auto px-6">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Projetos Construsteel: A Materialização do Nosso Ecossistema Inteligente</h1>
          <p className="text-lg md:text-xl text-gray-300 max-w-3xl mx-auto">
            Explore como nossa expertise em construção industrializada, utilizando perfis de aço e painéis LightWall, transforma desafios em soluções de excelência para os segmentos Residencial, Corporativo/Comercial e Agro.
          </p>
        </div>
      </section>

      <section className="py-8 bg-gray-100">
        <div className="container mx-auto px-6">
          <div className="flex flex-wrap gap-4 items-center justify-center mb-8">
            <button className="px-4 py-2 text-sm font-semibold text-white bg-orange-500 rounded-md hover:bg-orange-600 transition-colors">Todos os Projetos</button>
            <button className="px-4 py-2 text-sm font-semibold text-gray-700 bg-white rounded-md hover:bg-gray-200 transition-colors border">Residencial</button>
            <button className="px-4 py-2 text-sm font-semibold text-gray-700 bg-white rounded-md hover:bg-gray-200 transition-colors border">Corporativo/Comercial</button>
            <button className="px-4 py-2 text-sm font-semibold text-gray-700 bg-white rounded-md hover:bg-gray-200 transition-colors border">Agronegócio</button>
          </div>
          <p className="text-center text-gray-600 text-sm">Exibindo {projetosFiltrados.length} projetos que demonstram nosso ecossistema em ação.</p>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projetosFiltrados.map((projeto) => (
              <div key={projeto.id} className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 flex flex-col">
                <Image src={projeto.imagemPrincipal} alt={projeto.titulo} width={400} height={300} className="w-full h-64 object-cover"/>
                <div className="p-6 flex flex-col flex-grow">
                  <h3 className="text-xl font-bold text-gray-800 mb-2">{projeto.titulo}</h3>
                  <p className="text-sm text-orange-500 font-semibold mb-2">{projeto.nicho} - {projeto.tipoProjeto}</p>
                  <p className="text-gray-600 text-sm mb-4 flex-grow">{projeto.descricaoBreve}</p>
                  <Link href={`/projetos/${projeto.id}`} className="mt-auto text-orange-500 hover:text-orange-600 font-semibold text-sm inline-flex items-center">
                    Ver Detalhes do Projeto <ChevronRight className="ml-1 w-4 h-4" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-orange-500 text-white">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Veja Como Nosso Ecossistema Transforma Desafios em Realizações. O Próximo Pode Ser o Seu!</h2>
          <p className="text-lg md:text-xl mb-8 max-w-2xl mx-auto">
            A Construsteel tem a expertise e a tecnologia para levar seu projeto residencial, corporativo ou do agronegócio a um novo patamar de eficiência e qualidade.
          </p>
          <div>
            <Link href="/contato?assunto=novo-projeto" className="bg-white hover:bg-gray-100 text-orange-500 font-bold py-3 px-8 rounded-lg text-lg mr-4 transition duration-300">
              Inicie Seu Projeto Conosco
            </Link>
            <Link href="/contato" className="bg-transparent hover:bg-white text-white hover:text-orange-500 border border-white font-bold py-3 px-8 rounded-lg text-lg transition duration-300">
              Entre em Contato com Nossos Especialistas
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}

