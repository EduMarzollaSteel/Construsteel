import type { Metadata } from "next";
import { Inter } from "next/font/google";
import Link from "next/link"; // Importar o Link
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Construsteel - Ecossistema de Construção Industrializada Inteligente",
  description: "Transformando projetos em realidade com agilidade, sustentabilidade e precisão, utilizando perfis de aço e a inovadora tecnologia de painéis LightWall.",
  keywords: "construsteel, construção industrializada, lightwall, perfis de aço, construção inteligente, residencial, corporativo, agronegócio"
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR" className="scroll-smooth">
      <body className={`${inter.className} bg-gray-50 text-gray-800 antialiased`}>
        <header className="bg-white shadow-md sticky top-0 z-50">
          <nav className="container mx-auto px-4 sm:px-6 lg:px-8 py-3 flex justify-between items-center">
            <div>
              <Link href="/" className="text-2xl font-bold text-orange-500 hover:text-orange-600 transition-colors">Construsteel</Link>
            </div>
            <div className="hidden md:flex items-center space-x-2 lg:space-x-4">
              <Link href="/sobre-nos" className="px-3 py-2 rounded-md text-sm font-medium text-gray-700 hover:text-orange-500 hover:bg-gray-100 transition-colors">Quem Somos</Link>
              <Link href="/solucoes" className="px-3 py-2 rounded-md text-sm font-medium text-gray-700 hover:text-orange-500 hover:bg-gray-100 transition-colors">Soluções Inteligentes</Link>
              <Link href="/projetos" className="px-3 py-2 rounded-md text-sm font-medium text-gray-700 hover:text-orange-500 hover:bg-gray-100 transition-colors">Projetos</Link>
              <Link href="/contato" className="px-3 py-2 rounded-md text-sm font-medium text-white bg-orange-500 hover:bg-orange-600 transition-colors">Contato</Link>
            </div>
            <div className="md:hidden">
              <button type="button" className="text-gray-700 hover:text-orange-500 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-orange-500" aria-controls="mobile-menu" aria-expanded="false">
                <span className="sr-only">Abrir menu principal</span>
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7"></path></svg>
              </button>
            </div>
          </nav>
        </header>
        <main className="min-h-screen">
          {children}
        </main>
        <footer className="bg-gray-800 text-white py-10 mt-16">
          <div className="container mx-auto px-6 text-center">
            <Link href="/" className="text-xl font-bold text-orange-500 hover:text-orange-400 transition-colors mb-2 inline-block">Construsteel</Link>
            <p className="text-sm text-gray-400 mb-4">Seu Ecossistema de Construção Industrializada.</p>
            <div className="mb-4">
              <Link href="/sobre-nos" className="text-sm text-gray-300 hover:text-orange-400 px-2">Quem Somos</Link>
              <Link href="/solucoes" className="text-sm text-gray-300 hover:text-orange-400 px-2">Soluções</Link>
              <Link href="/projetos" className="text-sm text-gray-300 hover:text-orange-400 px-2">Projetos</Link>
              <Link href="/contato" className="text-sm text-gray-300 hover:text-orange-400 px-2">Contato</Link>
              <Link href="/politica-de-privacidade" className="text-sm text-gray-300 hover:text-orange-400 px-2">Política de Privacidade</Link>
            </div>
            <p className="text-xs text-gray-500">&copy; {new Date().getFullYear()} Construsteel. Todos os direitos reservados.</p>
            <p className="text-xs text-gray-500 mt-1">Desenvolvido com paixão e tecnologia de ponta.</p>
          </div>
        </footer>
      </body>
    </html>
  );
}

