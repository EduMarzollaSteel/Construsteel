import Link from "next/link";
import Image from "next/image";
import { Users, Award, Target, Eye, CheckSquare, Leaf, Handshake, Clock, Zap } from "lucide-react"; // ChevronRight, Briefcase, ShieldCheck removidos

export default function SobreNosPage() {
  const valores = [
    { nome: "Cliente no Centro", icone: Users, descricao: "Compreender profundamente as dores e necessidades dos nossos clientes para entregar soluções que verdadeiramente agreguem valor." },
    { nome: "Inovação e Inteligência Construtiva", icone: Zap, descricao: "Buscar e aplicar continuamente as mais avançadas tecnologias e processos da construção industrializada, como os perfis de aço e painéis LightWall." },
    { nome: "Excelência e Qualidade Superior", icone: Award, descricao: "Compromisso inabalável com a mais alta qualidade em cada etapa do nosso ecossistema, garantindo durabilidade e performance." },
    { nome: "Sustentabilidade e Responsabilidade", icone: Leaf, descricao: "Promover práticas construtivas que minimizem o impacto ambiental e promovam o uso eficiente de recursos." },
    { nome: "Expertise e Resiliência", icone: Clock, descricao: "Valorizar nossos 30 anos de experiência e a capacidade de adaptação, aplicando nosso conhecimento para enfrentar desafios complexos." },
    { nome: "Previsibilidade e Transparência", icone: CheckSquare, descricao: "Conduzir todos os projetos com clareza, honestidade e processos bem definidos, assegurando previsibilidade de custos e prazos." },
    { nome: "Compromisso com Resultados", icone: Target, descricao: "Focar na entrega de soluções que superem as expectativas, gerando valor real para nossos clientes." },
    { nome: "Colaboração e Ecossistema", icone: Handshake, descricao: "Fomentar um ambiente de parceria e colaboração com clientes, fornecedores e colaboradores, fortalecendo nosso ecossistema." },
  ];

  return (
    <>
      {/* Seção de Título da Página */}
      <section className="bg-gray-700 py-20 text-white text-center" style={{ backgroundImage: "url(\"/sobre-nos-banner.jpg\")", backgroundSize: "cover", backgroundPosition: "center" }}>
        <div className="container mx-auto px-6">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Construsteel: 30 Anos Construindo o Futuro como um Ecossistema de Inovação</h1>
          <p className="text-lg md:text-xl text-gray-300 max-w-3xl mx-auto">
            Nossa história é moldada pela expertise, resiliência e pela busca incessante por soluções que transformam a construção civil no Brasil.
          </p>
        </div>
      </section>

      {/* Seção: Nossa Trajetória */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-6 text-center">Três Décadas de Evolução: Fundando o Ecossistema de Construção Industrializada da Construsteel</h2>
          <div className="text-gray-600 space-y-6 max-w-4xl mx-auto text-lg">
            <p>
              Há 30 anos, a Construsteel nasceu com o propósito de inovar. Ao longo dessa jornada, acumulamos uma vasta expertise, superamos desafios e nos adaptamos às dinâmicas do mercado, evoluindo de uma construtora tradicional para um completo ecossistema de construção industrializada. Nosso compromisso sempre foi entregar mais que edificações: entregamos soluções inteligentes, sustentáveis e que resolvem as dores reais dos nossos clientes.
            </p>
            <p>
              Hoje, esse ecossistema integra planejamento estratégico, engenharia de ponta, a mais moderna tecnologia de perfis de aço combinada com os painéis LightWall, e uma gestão de projetos focada na eficiência e na satisfação total. Cada projeto é um reflexo da nossa resiliência e da nossa paixão por construir o futuro.
            </p>
          </div>
          <div className="text-center mt-10 text-2xl font-semibold text-orange-500">30 Anos de Expertise e Inovação Contínua</div>
          <div className="mt-12 text-center text-gray-500 italic">
            (Aqui poderia entrar uma linha do tempo visual com os marcos da Construsteel)
          </div>
        </div>
      </section>

      {/* Seção: Missão, Visão e Valores */}
      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-12 text-center">O Alicerce do Nosso Ecossistema: Missão, Visão e Valores</h2>
          <p className="text-gray-600 mb-10 text-center max-w-3xl mx-auto">
            Estes são os princípios que guiam cada decisão e ação dentro do ecossistema Construsteel, refletindo nosso compromisso com clientes, parceiros e com o futuro da construção.
          </p>
          <div className="grid md:grid-cols-1 lg:grid-cols-2 gap-10 mb-12">
            <div className="bg-white p-8 rounded-lg shadow-lg">
              <Target className="w-12 h-12 text-orange-500 mb-4" />
              <h3 className="text-2xl font-bold text-gray-800 mb-3">Nossa Missão</h3>
              <p className="text-gray-600">
                Transformar o cenário da construção civil brasileira, oferecendo um ecossistema completo de soluções industrializadas inteligentes e sustentáveis. Através da nossa expertise de três décadas e da aplicação de tecnologias inovadoras como os perfis de aço e painéis LightWall, entregamos projetos residenciais, corporativos e para o agronegócio com agilidade, previsibilidade, qualidade superior e respeito ao meio ambiente, solucionando as dores de nossos clientes e superando suas expectativas.
              </p>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-lg">
              <Eye className="w-12 h-12 text-orange-500 mb-4" />
              <h3 className="text-2xl font-bold text-gray-800 mb-3">Nossa Visão</h3>
              <p className="text-gray-600">
                Ser a principal referência e o parceiro mais confiável em construção industrializada no Brasil, reconhecidos pela excelência de nosso ecossistema de soluções, pela inovação contínua em tecnologias como LightWall, e pelo impacto positivo que geramos na produtividade, sustentabilidade e satisfação dos nossos clientes nos segmentos residencial, corporativo e do agronegócio, consolidando o futuro da construção inteligente no país.
              </p>
            </div>
          </div>
          <div>
            <h3 className="text-2xl md:text-3xl font-bold text-gray-800 mb-8 text-center">Nossos Valores</h3>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {valores.map((valor) => {
                const Icone = valor.icone;
                return (
                  <div key={valor.nome} className="bg-white p-6 rounded-lg shadow-md text-center hover:shadow-lg transition-shadow duration-300">
                    <Icone className="w-10 h-10 text-orange-500 mx-auto mb-3" />
                    <h4 className="text-lg font-semibold text-gray-700 mb-2">{valor.nome}</h4>
                    <p className="text-gray-600 text-sm">{valor.descricao}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Seção: O Ecossistema Construsteel em Ação (Equipe) */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-6">Nossa Equipe: A Força por Trás da Inovação</h2>
          <p className="text-gray-600 mb-8 max-w-3xl mx-auto">
            Nosso ecossistema é formado por profissionais apaixonados e altamente qualificados, dedicados a transformar projetos em realidade. Acreditamos que a força da Construsteel reside na expertise e no comprometimento de nossa equipe.
          </p>
          <div className="flex flex-wrap justify-center gap-8">
            {[1,2,3,4].map(i => (
              <div key={i} className="text-center">
                <Image src={`https://via.placeholder.com/150x150.png?text=Equipe+${i}`} alt={`Membro da Equipe ${i}`} width={150} height={150} className="w-32 h-32 rounded-full mx-auto mb-2 shadow-md"/>
                <h4 className="font-semibold text-gray-700">Nome do Profissional {i}</h4>
                <p className="text-sm text-orange-500">Cargo/Especialidade</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Seção: Nossos Diferenciais Estratégicos */}
      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-12 text-center">Por Que o Ecossistema Construsteel é a Escolha Inteligente?</h2>
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <Image src="https://via.placeholder.com/500x350.png?text=Diferenciais+Construsteel" alt="Diferenciais Construsteel" width={500} height={350} className="rounded-lg shadow-xl mx-auto" />
            </div>
            <div className="space-y-6">
              <div className="flex items-start">
                <CheckSquare className="w-7 h-7 text-orange-500 mr-3 flex-shrink-0 mt-1" />
                <div>
                  <h4 className="text-xl font-semibold text-gray-700">Soluções Completas e Integradas</h4>
                  <p className="text-gray-600">Desde a concepção e engenharia até a fabricação e montagem, controlamos todo o processo do nosso ecossistema.</p>
                </div>
              </div>
              <div className="flex items-start">
                <Users className="w-7 h-7 text-orange-500 mr-3 flex-shrink-0 mt-1" />
                <div>
                  <h4 className="text-xl font-semibold text-gray-700">Foco na Dor do Cliente</h4>
                  <p className="text-gray-600">Entendemos profundamente os desafios dos nichos Residencial, Corporativo e Agro, oferecendo soluções que realmente fazem a diferença.</p>
                </div>
              </div>
              <div className="flex items-start">
                <Leaf className="w-7 h-7 text-orange-500 mr-3 flex-shrink-0 mt-1" />
                <div>
                  <h4 className="text-xl font-semibold text-gray-700">Compromisso com a Sustentabilidade</h4>
                  <p className="text-gray-600">Práticas que respeitam o meio ambiente em todo o ciclo de vida do projeto, utilizando tecnologias como LightWall.</p>
                </div>
              </div>
              <div className="flex items-start">
                <Handshake className="w-7 h-7 text-orange-500 mr-3 flex-shrink-0 mt-1" />
                <div>
                  <h4 className="text-xl font-semibold text-gray-700">Parceria de Longo Prazo</h4>
                  <p className="text-gray-600">Buscamos construir relacionamentos sólidos e de confiança com nossos clientes, baseados em transparência e resultados.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Seção: Compromisso com a Qualidade e Certificações */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-6">Excelência Assegurada em Cada Etapa do Nosso Ecossistema</h2>
          <p className="text-gray-600 mb-8 max-w-3xl mx-auto">
            Nosso compromisso com a qualidade dos materiais (perfis de aço, painéis LightWall) e processos é atestado por rigorosos controles e, quando aplicável, por certificações do setor.
          </p>
          <div className="flex flex-wrap justify-center items-center gap-8 opacity-75">
            {[1,2,3].map(i => <Image key={i} src={`https://via.placeholder.com/150x75.png?text=Certificação+${i}`} alt={`Certificação ${i}`} width={150} height={75} className="h-16" />)}
          </div>
        </div>
      </section>

      {/* Call-to-Action (CTA) */}
      <section className="py-20 bg-orange-500 text-white">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Faça Parte da Revolução na Construção. Fale com o Ecossistema Construsteel.</h2>
          <div>
            <Link href="/solucoes" className="bg-white hover:bg-gray-100 text-orange-500 font-bold py-3 px-8 rounded-lg text-lg mr-4 transition duration-300">
              Descubra Nossas Soluções Inteligentes
            </Link>
            <Link href="/contato" className="bg-transparent hover:bg-white text-white hover:text-orange-500 border border-white font-bold py-3 px-8 rounded-lg text-lg transition duration-300">
              Entre em Contato
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}

