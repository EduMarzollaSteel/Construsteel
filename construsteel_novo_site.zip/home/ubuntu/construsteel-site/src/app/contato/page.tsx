import Link from "next/link";
import { MapPin, Phone, Mail, Clock, Users, Award, Zap, Handshake, Send, MessageSquare, Briefcase } from "lucide-react"; // Removidos: ChevronRight, Leaf, ShieldCheck, Building, Tractor

export default function ContatoPage() {
  const porQueFalar = [
    { titulo: "Atendimento Especializado", descricao: "Consultoria focada no seu nicho e na solução da sua dor.", icone: Users },
    { titulo: "Expertise de 30 Anos", descricao: "Acesso a um conhecimento consolidado em construção industrializada.", icone: Award },
    { titulo: "Tecnologia de Ponta", descricao: "Soluções com perfis de aço e painéis LightWall.", icone: Zap },
    { titulo: "Compromisso com Seu Projeto", descricao: "Da concepção à entrega, um parceiro dedicado.", icone: Handshake },
  ];

  return (
    <>
      <section className="bg-gray-700 py-20 text-white text-center" style={{ backgroundImage: "url(\"/contato-banner.jpg\")", backgroundSize: "cover", backgroundPosition: "center" }}>
        <div className="container mx-auto px-6">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Fale com o Ecossistema Construsteel</h1>
          <p className="text-lg md:text-xl text-gray-300 max-w-3xl mx-auto">
            Estamos prontos para entender suas necessidades e oferecer a melhor solução em construção industrializada, utilizando perfis de aço e painéis LightWall. Nossa equipe de especialistas aguarda seu contato.
          </p>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-12 items-start">
            <div>
              <h2 className="text-2xl font-bold text-gray-800 mb-6">Conecte-se Diretamente Conosco</h2>
              <p className="text-gray-600 mb-8">
                Nosso ecossistema de especialistas está à disposição para discutir seu projeto Residencial, Corporativo/Comercial ou no Agronegócio.
              </p>
              <div className="space-y-6">
                <div className="flex items-start">
                  <MapPin className="w-6 h-6 text-orange-500 mr-4 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-gray-700">Endereço</h4>
                    <p className="text-gray-600">Rua Exemplo de Endereço, 123, Bairro, Cidade - UF, CEP 00000-000</p>
                    <Link href="#mapa" className="text-sm text-orange-500 hover:underline">Ver no mapa</Link>
                  </div>
                </div>
                <div className="flex items-start">
                  <Phone className="w-6 h-6 text-orange-500 mr-4 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-gray-700">Telefone</h4>
                    <p className="text-gray-600"><Link href="tel:+5511999998888" className="hover:text-orange-500">(11) 99999-8888</Link> (Comercial)</p>
                    <p className="text-gray-600"><Link href="tel:+5511777776666" className="hover:text-orange-500">(11) 77777-6666</Link> (WhatsApp)</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <Mail className="w-6 h-6 text-orange-500 mr-4 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-gray-700">E-mail</h4>
                    <p className="text-gray-600"><Link href="mailto:contato@construsteel.com.br" className="hover:text-orange-500">contato@construsteel.com.br</Link></p>
                  </div>
                </div>
                <div className="flex items-start">
                  <Clock className="w-6 h-6 text-orange-500 mr-4 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-gray-700">Horário de Atendimento</h4>
                    <p className="text-gray-600">Segunda a Sexta, das 8h às 18h.</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gray-50 p-8 rounded-lg shadow-lg">
              <h2 className="text-2xl font-bold text-gray-800 mb-2">Envie Sua Mensagem para Nosso Ecossistema</h2>
              <p className="text-sm text-gray-600 mb-6">Para que possamos direcionar sua solicitação ao especialista mais adequado, por favor, preencha o formulário abaixo. Quanto mais detalhes você fornecer, mais assertiva será nossa resposta.</p>
              <form action="#" method="POST" className="space-y-6">
                <div>
                  <label htmlFor="nome" className="block text-sm font-medium text-gray-700 mb-1">Nome Completo*</label>
                  <input type="text" name="nome" id="nome" required className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500" />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">E-mail*</label>
                  <input type="email" name="email" id="email" required className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500" />
                </div>
                <div>
                  <label htmlFor="telefone" className="block text-sm font-medium text-gray-700 mb-1">Telefone*</label>
                  <input type="tel" name="telefone" id="telefone" required className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500" />
                </div>
                <div>
                  <label htmlFor="empresa" className="block text-sm font-medium text-gray-700 mb-1">Empresa (Opcional)</label>
                  <input type="text" name="empresa" id="empresa" className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500" />
                </div>
                <div>
                  <label htmlFor="nicho_interesse" className="block text-sm font-medium text-gray-700 mb-1">Nicho de Interesse*</label>
                  <select id="nicho_interesse" name="nicho_interesse" required className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500 bg-white">
                    <option value="">Selecione um nicho</option>
                    <option value="residencial">Residencial</option>
                    <option value="corporativo_comercial">Corporativo/Comercial</option>
                    <option value="agronegocio">Agronegócio</option>
                    <option value="outros">Outros</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="assunto" className="block text-sm font-medium text-gray-700 mb-1">Assunto/Tipo de Solicitação*</label>
                  <select id="assunto" name="assunto" required className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500 bg-white">
                    <option value="">Selecione o assunto</option>
                    <option value="orcamento">Solicitação de Orçamento</option>
                    <option value="duvida_tecnica">Dúvida Técnica sobre LightWall</option>
                    <option value="info_ecossistema">Informações sobre o Ecossistema Construsteel</option>
                    <option value="parcerias">Parcerias</option>
                    <option value="agendar_conversa">Agendar uma Conversa</option>
                    <option value="outros_assuntos">Outros Assuntos</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="mensagem" className="block text-sm font-medium text-gray-700 mb-1">Mensagem*</label>
                  <textarea id="mensagem" name="mensagem" rows={4} required className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500"></textarea>
                </div>
                <div className="flex items-start">
                  <input id="consentimento_lgpd" name="consentimento_lgpd" type="checkbox" required className="h-4 w-4 text-orange-600 border-gray-300 rounded focus:ring-orange-500 mt-1 mr-2" />
                  <label htmlFor="consentimento_lgpd" className="text-sm text-gray-600">
                    Concordo com o uso dos meus dados para contato, conforme a <Link href="/politica-de-privacidade" className="text-orange-500 hover:underline">Política de Privacidade</Link>.
                  </label>
                </div>
                <div>
                  <button type="submit" className="w-full flex justify-center items-center py-3 px-6 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-orange-500 hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 transition-colors">
                    <Send className="w-5 h-5 mr-2" /> Enviar para Análise
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-12 text-center">Ao Contatar o Ecossistema Construsteel, Você Garante:</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {porQueFalar.map((item) => {
              const IconeItem = item.icone;
              return (
                <div key={item.titulo} className="bg-white p-6 rounded-lg shadow-md text-center hover:shadow-lg transition-shadow duration-300">
                  <IconeItem className="w-10 h-10 text-orange-500 mx-auto mb-4" />
                  <h4 className="text-lg font-semibold text-gray-700 mb-2">{item.titulo}</h4>
                  <p className="text-gray-600 text-sm">{item.descricao}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section id="mapa" className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-8 text-center">Visite a Sede do Nosso Ecossistema Construtivo</h2>
          <div className="aspect-w-16 aspect-h-9 bg-gray-200 rounded-lg shadow-lg overflow-hidden">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3657.1066900000003!2d-46.65653078447935!3d-23.564074567599997!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce59c8da0aa315%3A0xd59f9431f2c90e84!2sAv.%20Paulista%2C%20S%C3%A3o%20Paulo%20-%20SP!5e0!3m2!1spt-BR!2sbr!4v1620000000000!5m2!1spt-BR!2sbr"
              width="100%"
              height="450"
              style={{ border:0 }}
              allowFullScreen={true}
              loading="lazy"
              title="Localização da Construsteel"
            ></iframe>
          </div>
        </div>
      </section>

      <section className="py-8 bg-gray-50">
        <div className="container mx-auto px-6 text-center">
          <h3 className="text-xl font-semibold text-gray-700 mb-4">Acompanhe Nosso Ecossistema nas Redes</h3>
          <div className="flex justify-center space-x-6">
            <Link href="#" className="text-gray-500 hover:text-orange-500 transition-colors"><Briefcase className="w-7 h-7" /></Link> {/* LinkedIn */}
            <Link href="#" className="text-gray-500 hover:text-orange-500 transition-colors"><MessageSquare className="w-7 h-7" /></Link> {/* Instagram */}
          </div>
        </div>
      </section>
    </>
  );
}

