import Link from "next/link";
import Image from "next/image";
import { ChevronRight, Building, Users, Zap, Leaf, TrendingUp, ShieldCheck, Home, Briefcase, Tractor } from "lucide-react";

export default function HomePage() {
  return (
    <>
      {/* Seção Hero */}
      <section className="relative h-[calc(100vh-68px)] flex items-center justify-center text-center bg-cover bg-center" style={{ backgroundImage: "url(\"/hero-background.jpg\")" }}>
        <div className="absolute inset-0 bg-black opacity-50"></div>
        <div className="relative z-10 p-6">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">Construsteel: Construção Inteligente, Resultados Superiores.</h1>
          <p className="text-lg md:text-xl text-gray-200 mb-8 max-w-3xl mx-auto">
            Somos um ecossistema de construção industrializada que transforma projetos em realidade com agilidade, sustentabilidade e precisão, utilizando perfis de aço e a inovadora tecnologia de painéis LightWall.
          </p>
          <div>
            <Link href="#solucoes" className="bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 px-8 rounded-lg text-lg mr-4 transition duration-300">
              Descubra Nossas Soluções Inteligentes
            </Link>
            <Link href="#contato" className="bg-transparent hover:bg-orange-500 text-orange-500 hover:text-white border border-orange-500 font-bold py-3 px-8 rounded-lg text-lg transition duration-300">
              Solicite um Orçamento
            </Link>
          </div>
        </div>
      </section>

      {/* Seção de Introdução / Quem Somos (Breve) */}
      <section id="quem-somos" className="py-16 bg-white">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-6">Construsteel: 30 Anos de Expertise em Construção Industrializada</h2>
          <p className="text-gray-600 mb-8 max-w-3xl mx-auto">
            Com três décadas de resiliência e expertise, a Construsteel se consolidou como um ecossistema de referência em construção industrializada. Nossa missão é transformar o cenário da construção, oferecendo soluções inteligentes e sustentáveis que resolvem as dores dos nossos clientes nos segmentos residencial, corporativo e agro. Conheça nossa história e os valores que nos movem.
          </p>
          <div className="text-2xl font-semibold text-orange-500 mb-8">30 Anos de Experiência e Resiliência</div>
          <Link href="/sobre-nos" className="text-orange-500 hover:text-orange-600 font-semibold flex items-center justify-center">
            Conheça nossa Missão, Visão e Valores <ChevronRight className="ml-1 w-5 h-5" />
          </Link>
        </div>
      </section>

      {/* Seção de Soluções Inteligentes por Nicho */}
      <section id="solucoes" className="py-16 bg-gray-100">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4 text-center">Soluções Sob Medida para Cada Desafio</h2>
          <p className="text-gray-600 mb-12 text-center max-w-3xl mx-auto">
            Entendemos as dores específicas de cada mercado. Por isso, nosso ecossistema de construção industrializada, com perfis de aço e painéis LightWall, oferece soluções personalizadas para os segmentos Residencial, Corporativo/Comercial e Agro.
          </p>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300">
              <Home className="w-12 h-12 text-orange-500 mb-4" />
              <h3 className="text-2xl font-bold text-gray-800 mb-3">Residencial: O Sonho da Casa Própria sem Dor de Cabeça.</h3>
              <p className="text-gray-600 mb-4">
                Construímos seu lar com previsibilidade, agilidade e qualidade superior, eliminando os imprevistos e a falta de mão de obra qualificada da construção tradicional.
              </p>
              <Link href="/solucoes#residencial" className="text-orange-500 hover:text-orange-600 font-semibold flex items-center">
                Soluções para seu Lar <ChevronRight className="ml-1 w-5 h-5" />
              </Link>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300">
              <Briefcase className="w-12 h-12 text-orange-500 mb-4" />
              <h3 className="text-2xl font-bold text-gray-800 mb-3">Corporativo e Comercial: Agilidade que Gera Lucro.</h3>
              <p className="text-gray-600 mb-4">
                Evite o lucro cessante por atrasos. Entregamos sua obra comercial ou corporativa em tempo recorde, com flexibilidade para futuras adaptações ou mudanças de ponto.
              </p>
              <Link href="/solucoes#corporativo" className="text-orange-500 hover:text-orange-600 font-semibold flex items-center">
                Soluções para seu Negócio <ChevronRight className="ml-1 w-5 h-5" />
              </Link>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300">
              <Tractor className="w-12 h-12 text-orange-500 mb-4" />
              <h3 className="text-2xl font-bold text-gray-800 mb-3">Agronegócio: Eficiência Construtiva no Campo.</h3>
              <p className="text-gray-600 mb-4">
                Superamos os desafios de mobilização e falta de mão de obra no campo. Nossas soluções industrializadas garantem rapidez e qualidade para suas instalações, onde quer que estejam.
              </p>
              <Link href="/solucoes#agro" className="text-orange-500 hover:text-orange-600 font-semibold flex items-center">
                Soluções para o Agro <ChevronRight className="ml-1 w-5 h-5" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Seção de Diferenciais do Ecossistema Construsteel (Tecnologia LightWall) */}
      <section id="tecnologia" className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4 text-center">A Inteligência do Nosso Ecossistema: Perfis de Aço e a Tecnologia LightWall</h2>
          <p className="text-gray-600 mb-12 text-center max-w-3xl mx-auto">
            Nosso ecossistema construtivo se baseia na combinação otimizada de perfis de aço estruturais com os inovadores painéis LightWall, garantindo um desempenho superior.
          </p>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 text-center">
            <div className="p-6">
              <Zap className="w-12 h-12 text-orange-500 mx-auto mb-3" />
              <h4 className="text-xl font-semibold text-gray-700 mb-2">Produtividade Imbatível</h4>
              <p className="text-gray-600 text-sm">Até 5x mais produtivo que a alvenaria convencional, otimizando seu tempo.</p>
            </div>
            <div className="p-6">
              <TrendingUp className="w-12 h-12 text-orange-500 mx-auto mb-3" />
              <h4 className="text-xl font-semibold text-gray-700 mb-2">Velocidade e Agilidade</h4>
              <p className="text-gray-600 text-sm">Redução drástica do tempo de obra, antecipando seus resultados.</p>
            </div>
            <div className="p-6">
              <Leaf className="w-12 h-12 text-orange-500 mx-auto mb-3" />
              <h4 className="text-xl font-semibold text-gray-700 mb-2">Sustentabilidade Real</h4>
              <p className="text-gray-600 text-sm">Menor desperdício, obra limpa e menor impacto ambiental.</p>
            </div>
            <div className="p-6">
              <ShieldCheck className="w-12 h-12 text-orange-500 mx-auto mb-3" />
              <h4 className="text-xl font-semibold text-gray-700 mb-2">Economia Inteligente</h4>
              <p className="text-gray-600 text-sm">Redução de materiais, mão de obra e custos indiretos.</p>
            </div>
            <div className="p-6">
              <Building className="w-12 h-12 text-orange-500 mx-auto mb-3" />
              <h4 className="text-xl font-semibold text-gray-700 mb-2">Qualidade e Durabilidade</h4>
              <p className="text-gray-600 text-sm">Resistência, conforto térmico e acústico, acabamento superior.</p>
            </div>
            <div className="p-6">
              <Users className="w-12 h-12 text-orange-500 mx-auto mb-3" />
              <h4 className="text-xl font-semibold text-gray-700 mb-2">Versatilidade de Aplicação</h4>
              <p className="text-gray-600 text-sm">Adaptável a diversos projetos e acabamentos, conforme sua necessidade.</p>
            </div>
          </div>
          <div className="text-center mt-10">
            {/* Ajustado para apontar para a seção de tecnologia na página de soluções */}
            <Link href="/solucoes#nossa-tecnologia" className="text-orange-500 hover:text-orange-600 font-semibold flex items-center justify-center">
              Saiba mais sobre a Tecnologia LightWall <ChevronRight className="ml-1 w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* Seção de Projetos de Sucesso (Portfólio Destacado) */}
      <section id="projetos" className="py-16 bg-gray-100">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-12 text-center">Projetos que Materializam Nossa Expertise</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3].map((p) => (
              <div key={p} className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
                <Image src={`https://via.placeholder.com/400x300.png?text=Projeto+Construsteel+${p}`} alt={`Projeto Construsteel ${p}`} width={400} height={300} className="w-full h-64 object-cover"/>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-800 mb-2">Projeto Exemplo {p}</h3>
                  <p className="text-sm text-orange-500 font-semibold mb-2">{p % 3 === 1 ? "Residencial" : p % 3 === 2 ? "Corporativo" : "Agro"}</p>
                  <p className="text-gray-600 text-sm mb-4">Breve descrição do projeto {p} e como o ecossistema Construsteel solucionou a dor do cliente.</p>
                  <Link href={`/projetos/exemplo-${p}`} className="text-orange-500 hover:text-orange-600 font-semibold text-sm flex items-center">
                    Ver Projeto Completo <ChevronRight className="ml-1 w-4 h-4" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
          <div className="text-center mt-12">
            <Link href="/projetos" className="bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 px-8 rounded-lg text-lg transition duration-300">
              Veja Todos os Projetos
            </Link>
          </div>
        </div>
      </section>

      {/* Seção de Clientes / Prova Social */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-12 text-center">Quem Confia no Ecossistema Construsteel</h2>
          <div className="flex flex-wrap justify-center items-center gap-8 opacity-75">
            {[1,2,3,4,5].map(i => <Image key={i} src={`https://via.placeholder.com/120x60.png?text=Cliente+${i}`} alt={`Cliente ${i}`} width={120} height={60} className="h-12" />)}
          </div>
          <div className="mt-12 max-w-2xl mx-auto text-center">
            <p className="text-gray-700 italic text-lg">
              &quot;A Construsteel revolucionou nosso projeto com agilidade e qualidade impressionantes. O sistema LightWall é realmente o futuro!&quot;
            </p>
            <p className="mt-2 text-gray-600 font-semibold">- Cliente Satisfeito, Setor Corporativo</p>
          </div>
        </div>
      </section>

      {/* Seção de Call-to-Action Secundário / Contato Rápido */}
      <section id="contato" className="py-20 bg-orange-500 text-white">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Pronto para Construir o Futuro com Inteligência?</h2>
          <p className="text-lg md:text-xl mb-8 max-w-2xl mx-auto">
            Nossa equipe de especialistas está pronta para entender seu desafio e propor a melhor solução com o ecossistema Construsteel.
          </p>
          <div>
            <Link href="/contato?assunto=orcamento" className="bg-white hover:bg-gray-100 text-orange-500 font-bold py-3 px-8 rounded-lg text-lg mr-4 transition duration-300">
              Solicite um Orçamento Detalhado
            </Link>
            <Link href="/contato" className="bg-transparent hover:bg-white text-white hover:text-orange-500 border border-white font-bold py-3 px-8 rounded-lg text-lg transition duration-300">
              Fale com Nossos Especialistas
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}

