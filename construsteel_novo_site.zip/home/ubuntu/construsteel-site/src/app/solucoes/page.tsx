import Link from "next/link";
import Image from "next/image";
import { ChevronRight, Home, Briefcase, Tractor, Settings, Users, Package, Truck, Construction, Building } from "lucide-react"; // Zap, Leaf, ShieldCheck, TrendingUp, CheckSquare removidos pois não estavam sendo usados diretamente, mas sim como parte de 'solucoesNicho' ou 'processoConstrusteel' onde o ícone é dinâmico. Se forem usados diretamente, precisam ser re-adicionados.

export default function SolucoesPage() {
  const solucoesNicho = [
    {
      nicho: "Residencial",
      titulo: "Residencial: Construindo Sonhos com Previsibilidade e Sem Dor de Cabeça.",
      dorAtendida: "Sabemos que o sonho da casa própria pode se tornar um pesadelo com obras tradicionais: prazos estourados, custos imprevisíveis, falta de mão de obra qualificada e muita dor de cabeça.",
      solucaoConstrusteel: "Nosso ecossistema industrializado, utilizando perfis de aço e painéis LightWall, transforma essa realidade. Oferecemos um processo construtivo ágil, limpo e com controle de qualidade rigoroso. Garantimos previsibilidade de custos e prazos, minimizamos a necessidade de mão de obra extensiva no canteiro e entregamos um lar com conforto térmico, acústico e durabilidade superior, para que sua única preocupação seja desfrutar.",
      beneficiosChave: ["Rapidez na entrega", "Custo final competitivo", "Sustentabilidade", "Conforto e Qualidade", "Menos imprevistos"],
      imagemDestaque: "/placeholder-residencial.jpg",
      ctaLink: "/projetos?nicho=residencial",
      ctaTexto: "Veja Projetos Residenciais",
      icone: Home,
    },
    {
      nicho: "Corporativo/Comercial",
      titulo: "Corporativo e Comercial: Agilidade que Impulsiona Seu Lucro.",
      dorAtendida: "No mundo dos negócios, tempo é dinheiro. Atrasos em obras comerciais ou corporativas significam lucro cessante e perda de oportunidades. Além disso, a necessidade de adaptação ou mudança de ponto pode ser um grande desafio.",
      solucaoConstrusteel: "Com o ecossistema Construsteel, seu empreendimento comercial ou corporativo ganha a agilidade que precisa. A construção industrializada com perfis de aço e painéis LightWall permite entregas em tempo recorde, muitas vezes antecipando o cronograma e permitindo que o retorno sobre o investimento comece mais cedo. A modularidade e leveza do sistema também facilitam futuras expansões, reformas ou até mesmo a desmontagem e realocação, oferecendo flexibilidade incomparável.",
      beneficiosChave: ["Retorno rápido do investimento", "Prazos otimizados", "Flexibilidade e Adaptabilidade", "Redução de lucro cessante", "Construção limpa e eficiente"],
      imagemDestaque: "/placeholder-corporativo.jpg",
      ctaLink: "/projetos?nicho=corporativo",
      ctaTexto: "Veja Cases Corporativos",
      icone: Briefcase,
    },
    {
      nicho: "Agronegócio",
      titulo: "Agronegócio: Eficiência e Durabilidade que Chegam ao Campo.",
      dorAtendida: "O agronegócio enfrenta desafios únicos: dificuldade de mobilização de mão de obra qualificada em áreas remotas, longas distâncias que encarecem a logística e atrasos que podem comprometer safras ou produção, resultando em lucro cessante.",
      solucaoConstrusteel: "Nosso ecossistema de construção industrializada é a resposta para esses desafios. Levamos eficiência e qualidade para o campo com nossos sistemas de perfis de aço e painéis LightWall. A fabricação em ambiente controlado e a montagem rápida no local minimizam a dependência de mão de obra especializada e reduzem drasticamente o tempo de obra, mesmo em locais de difícil acesso. Entregamos instalações robustas, duráveis e com excelente desempenho térmico, ideais para as necessidades do agro.",
      beneficiosChave: ["Mobilização eficiente", "Rapidez construtiva em áreas remotas", "Durabilidade e Baixa Manutenção", "Redução de perdas e atrasos", "Qualidade controlada"],
      imagemDestaque: "/placeholder-agro.jpg",
      ctaLink: "/projetos?nicho=agro",
      ctaTexto: "Conheça Soluções para o Agro",
      icone: Tractor,
    }
  ];

  const processoConstrusteel = [
    { etapa: "Consultoria e Entendimento das Dores", descricao: "Análise aprofundada das necessidades do cliente e do nicho.", icone: Users },
    { etapa: "Projeto e Engenharia de Detalhamento", descricao: "Uso de BIM e softwares avançados para otimizar o design e a compatibilização dos sistemas (perfis de aço + LightWall).", icone: Settings },
    { etapa: "Fabricação Industrializada", descricao: "Produção precisa dos perfis de aço e painéis LightWall em ambiente controlado.", icone: Package },
    { etapa: "Logística Inteligente", descricao: "Transporte otimizado dos componentes para o canteiro.", icone: Truck },
    { etapa: "Montagem Ágil e Limpa", descricao: "Equipes especializadas garantem uma montagem rápida, segura e com mínimo desperdício.", icone: Construction },
    { etapa: "Acabamentos e Entrega", descricao: "Flexibilidade para diversos tipos de acabamento, com entrega no prazo e qualidade assegurada.", icone: Building },
  ];

  return (
    <>
      <section className="bg-gray-700 py-20 text-white text-center" style={{ backgroundImage: "url(\"/solucoes-banner.jpg\")", backgroundSize: "cover", backgroundPosition: "center" }}>
        <div className="container mx-auto px-6">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Soluções Inteligentes do Ecossistema Construsteel para Cada Desafio</h1>
          <p className="text-lg md:text-xl text-gray-300 max-w-3xl mx-auto">
            Transformamos seus projetos em realidade com agilidade, sustentabilidade e precisão, utilizando nosso ecossistema de construção industrializada com perfis de aço e a inovadora tecnologia de painéis LightWall.
          </p>
        </div>
      </section>

      <section id="nossa-tecnologia" className="py-16 bg-white">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-6">Entendendo Suas Dores, Entregando Valor Real</h2>
          <p className="text-gray-600 text-lg max-w-4xl mx-auto">
            Na Construsteel, compreendemos que cada projeto é único e cada mercado possui desafios específicos. Por isso, nosso ecossistema de construção industrializada foi desenhado para oferecer mais do que edificações: entregamos soluções personalizadas que curam as dores dos segmentos Residencial, Corporativo/Comercial e do Agronegócio. Combinamos 30 anos de expertise com a tecnologia de ponta de perfis de aço e painéis LightWall para garantir resultados superiores.
          </p>
        </div>
      </section>

      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-12 text-center">Descubra como o ecossistema Construsteel atende às demandas específicas do seu setor:</h2>
          <div className="space-y-16">
            {solucoesNicho.map((solucao, index) => {
              const IconeNicho = solucao.icone;
              return (
                <div key={solucao.nicho} id={solucao.nicho.toLowerCase()} className={`flex flex-col md:flex-row items-center gap-8 scroll-mt-20 ${index % 2 !== 0 ? "md:flex-row-reverse" : ""}`}>
                  <div className="md:w-1/2">
                    <Image src={solucao.imagemDestaque} alt={`Solução Construsteel para ${solucao.nicho}`} width={600} height={400} className="rounded-lg shadow-xl w-full h-auto object-cover" />
                  </div>
                  <div className="md:w-1/2">
                    <IconeNicho className="w-12 h-12 text-orange-500 mb-4" />
                    <h3 className="text-2xl font-bold text-gray-800 mb-3">{solucao.titulo}</h3>
                    <p className="text-gray-700 font-semibold mb-2">Dor Atendida:</p>
                    <p className="text-gray-600 mb-4 italic">{solucao.dorAtendida}</p>
                    <p className="text-gray-700 font-semibold mb-2">A Solução Construsteel:</p>
                    <p className="text-gray-600 mb-4">{solucao.solucaoConstrusteel}</p>
                    <p className="text-gray-700 font-semibold mb-2">Benefícios Chave:</p>
                    <ul className="list-disc list-inside text-gray-600 mb-6 space-y-1">
                      {solucao.beneficiosChave.map(beneficio => <li key={beneficio}>{beneficio}</li>)}
                    </ul>
                    <Link href={solucao.ctaLink} className="bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 px-6 rounded-lg text-md transition duration-300 inline-flex items-center">
                      {solucao.ctaTexto} <ChevronRight className="ml-2 w-5 h-5" />
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-12 text-center">Da Concepção à Entrega: Precisão e Tecnologia em Cada Etapa do Ecossistema Construsteel</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {processoConstrusteel.map((item) => {
              const IconeProcesso = item.icone;
              return (
                <div key={item.etapa} className="bg-gray-50 p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300">
                  <IconeProcesso className="w-10 h-10 text-orange-500 mb-3" />
                  <h4 className="text-xl font-semibold text-gray-700 mb-2">{item.etapa}</h4>
                  <p className="text-gray-600 text-sm">{item.descricao}</p>
                </div>
              );
            })}
          </div>
          <p className="text-center mt-10 text-gray-700 text-lg">Nosso ecossistema integrado garante controle de qualidade, tecnologia de ponta e eficiência em cada fase do seu projeto.</p>
        </div>
      </section>

      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-12 text-center">A Vanguarda da Construção: A Sinergia entre Perfis de Aço e Painéis LightWall</h2>
          <div className="grid md:grid-cols-2 gap-10 items-center">
            <div>
              <h3 className="text-2xl font-semibold text-gray-700 mb-3">Perfis de Aço Estruturais</h3>
              <p className="text-gray-600 mb-6">A espinha dorsal da nossa construção. Leves, resistentes e fabricados com precisão milimétrica, os perfis de aço galvanizado garantem uma estrutura sólida, durável e com montagem ágil, reduzindo o tempo de obra e o desperdício de materiais.</p>
              <h3 className="text-2xl font-semibold text-gray-700 mb-3">Painéis LightWall</h3>
              <p className="text-gray-600">A inovação que redefine fechamentos. Com núcleo em EPS de alta densidade, revestido por argamassa cimentícia e aditivos especiais, os painéis LightWall oferecem produtividade imbatível, isolamento térmico e acústico superior, resistência ao fogo e uma superfície pronta para acabamento, otimizando cada etapa da sua obra.</p>
            </div>
            <div>
              <Image src="/placeholder-tecnologia.jpg" alt="Tecnologia Construsteel: Perfis de Aço e Painéis LightWall" width={500} height={350} className="rounded-lg shadow-xl mx-auto" />
            </div>
          </div>
          <div className="mt-10 text-center">
            <h3 className="text-2xl font-semibold text-gray-700 mb-3">A Combinação Perfeita</h3>
            <p className="text-gray-600 max-w-3xl mx-auto">
              A união inteligente dos perfis de aço com os painéis LightWall resulta em um sistema construtivo de alta performance, mais eficiente, sustentável e versátil que os métodos tradicionais. É a tecnologia do ecossistema Construsteel trabalhando para o sucesso do seu projeto.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-orange-500 text-white">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Pronto para Solucionar Seu Desafio Construtivo com Inteligência?</h2>
          <p className="text-lg md:text-xl mb-8 max-w-2xl mx-auto">
            O ecossistema Construsteel está preparado para oferecer a melhor solução para seu projeto residencial, corporativo ou no agronegócio.
          </p>
          <div>
            <Link href="/contato?assunto=proposta" className="bg-white hover:bg-gray-100 text-orange-500 font-bold py-3 px-8 rounded-lg text-lg mr-4 transition duration-300">
              Solicite uma Proposta Detalhada
            </Link>
            <Link href="/contato" className="bg-transparent hover:bg-white text-white hover:text-orange-500 border border-white font-bold py-3 px-8 rounded-lg text-lg transition duration-300">
              Fale com Nossos Especialistas
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}

